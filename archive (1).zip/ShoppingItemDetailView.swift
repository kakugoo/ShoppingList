import SwiftUI

struct ShoppingItemDetailView: View {
    @Binding var item: ShoppingItem

    private var normalizedName: String {
        item.name
            .split(whereSeparator: { $0.isWhitespace })
            .joined(separator: " ")
    }

    var body: some View {
        Form {
            TextField("Название", text: $item.name)
                .onChange(of: item.name) { oldValue, newValue in
                    if newValue.isEmpty {
                        return
                    }
                }

            Picker("Категория", selection: $item.category) {
                ForEach(ShoppingCategory.allCases) { category in
                    Label(
                        category.rawValue,
                        systemImage: category.icon
                    )
                    .tag(category)
                }
            }

            HStack {
                Image(systemName: item.category.icon)
                    .foregroundStyle(item.category.color)

                Text(item.category.rawValue)
            }

            Stepper(
                "Количество: \(item.quantity)",
                value: $item.quantity,
                in: 1...99
            )

            Toggle("Куплено", isOn: $item.isPurchased)
        }
        .navigationTitle("Покупка")
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear {
            if !normalizedName.isEmpty {
                item.name = normalizedName
            }
        }
    }
}
