import SwiftUI

enum PurchaseFilter: String, CaseIterable, Identifiable {
    case all = "Все"
    case needed = "Нужно купить"
    case purchased = "Куплено"

    var id: Self { self }
}

enum SortOption: String, CaseIterable, Identifiable {
    case name = "По названию"
    case category = "По категории"
    case quantity = "По количеству"

    var id: Self { self }
}

struct ContentView: View {
    @State private var items = ShoppingStorage.load()

    @State private var searchText = ""
    @State private var showingAddItem = false

    @State private var selectedFilter: PurchaseFilter = .all
    @State private var sortOption: SortOption = .name

    private var remainingCount: Int {
        items.filter { !$0.isPurchased }.count
    }

    private var visibleItems: [ShoppingItem] {
        let filteredItems = items.filter { item in

            let matchesSearch =
                searchText.isEmpty ||
                item.name.localizedCaseInsensitiveContains(searchText) ||
                item.category.rawValue.localizedCaseInsensitiveContains(searchText)

            let matchesFilter: Bool

            switch selectedFilter {
            case .all:
                matchesFilter = true

            case .needed:
                matchesFilter = !item.isPurchased

            case .purchased:
                matchesFilter = item.isPurchased
            }

            return matchesSearch && matchesFilter
        }

        return filteredItems.sorted { first, second in
            switch sortOption {
            case .name:
                return first.name.localizedCaseInsensitiveCompare(
                    second.name
                ) == .orderedAscending

            case .category:
                return first.category.rawValue.localizedCaseInsensitiveCompare(
                    second.category.rawValue
                ) == .orderedAscending

            case .quantity:
                return first.quantity < second.quantity
            }
        }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("Осталось купить: \(remainingCount)")
                        .font(.headline)

                    Picker("Фильтр", selection: $selectedFilter) {
                        ForEach(PurchaseFilter.allCases) { filter in
                            Text(filter.rawValue)
                                .tag(filter)
                        }
                    }
                    .pickerStyle(.segmented)
                }

                if visibleItems.isEmpty {
                    ContentUnavailableView(
                        "Покупки не найдены",
                        systemImage: "cart"
                    )
                } else {
                    ForEach(visibleItems) { item in
                        NavigationLink(value: item.id) {
                            ShoppingItemRow(item: item) {
                                toggle(item)
                            }
                        }
                    }
                    .onDelete(perform: delete)
                }
            }
            .navigationTitle("Покупки")
            .searchable(
                text: $searchText,
                prompt: "Название или категория"
            )
            .toolbar {
                Menu {
                    Picker("Сортировка", selection: $sortOption) {
                        ForEach(SortOption.allCases) { option in
                            Text(option.rawValue)
                                .tag(option)
                        }
                    }
                } label: {
                    Label(
                        "Сортировка",
                        systemImage: "arrow.up.arrow.down"
                    )
                }

                Button("Добавить", systemImage: "plus") {
                    showingAddItem = true
                }
            }
            .sheet(isPresented: $showingAddItem) {
                AddItemView { newItem in
                    items.append(newItem)
                }
            }
            .navigationDestination(for: UUID.self) { id in
                if let index = items.firstIndex(
                    where: { $0.id == id }
                ) {
                    ShoppingItemDetailView(
                        item: $items[index]
                    )
                }
            }
            .onChange(of: items) { oldItems, newItems in
                ShoppingStorage.save(newItems)
            }
        }
    }

    private func toggle(_ item: ShoppingItem) {
        guard let index = items.firstIndex(
            where: { $0.id == item.id }
        ) else {
            return
        }

        items[index].isPurchased.toggle()
    }

    private func delete(at offsets: IndexSet) {
        let ids = offsets.map {
            visibleItems[$0].id
        }

        items.removeAll {
            ids.contains($0.id)
        }
    }
}

#Preview {
    ContentView()
}
