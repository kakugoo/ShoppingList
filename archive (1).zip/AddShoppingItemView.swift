import SwiftUI

struct AddItemView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var category: ShoppingCategory = .food
    @State private var quantity = 1

    let onSave: (ShoppingItem) -> Void

    private var normalizedName: String {
        name
            .split(whereSeparator: { $0.isWhitespace })
            .joined(separator: " ")
    }

    private var isValid: Bool {
        !normalizedName.isEmpty &&
        (1...99).contains(quantity)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Название") {
                    TextField("Название покупки", text: $name)
                }

                Section("Категория") {
                    Picker("Выберите категорию", selection: $category) {
                        ForEach(ShoppingCategory.allCases) { option in
                            Label(
                                option.rawValue,
                                systemImage: option.icon
                            )
                            .tag(option)
                        }
                    }

                    HStack {
                        Image(systemName: category.icon)
                            .foregroundStyle(category.color)

                        Text(category.rawValue)
                    }
                }

                Section("Количество") {
                    Stepper(
                        "Количество: \(quantity)",
                        value: $quantity,
                        in: 1...99
                    )
                }
            }
            .navigationTitle("Новая покупка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") {
                        dismiss()
                    }
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        guard isValid else {
                            return
                        }

                        let item = ShoppingItem(
                            name: normalizedName,
                            category: category,
                            quantity: quantity
                        )

                        onSave(item)
                        dismiss()
                    }
                    .disabled(!isValid)
                }
            }
        }
    }
}

#Preview {
    AddItemView { _ in }
}
