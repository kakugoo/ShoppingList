import SwiftUI

enum ShoppingCategory: String, CaseIterable, Codable, Identifiable {
    case food = "Продукты"
    case home = "Дом"
    case study = "Учёба"
    case electronics = "Электроника"
    case clothing = "Одежда"
    case other = "Другое"

    var id: String {
        rawValue
    }

    var icon: String {
        switch self {
        case .food:
            return "cart.fill"
        case .home:
            return "house.fill"
        case .study:
            return "book.fill"
        case .electronics:
            return "laptopcomputer"
        case .clothing:
            return "tshirt.fill"
        case .other:
            return "square.grid.2x2.fill"
        }
    }

    var color: Color {
        switch self {
        case .food:
            return .green
        case .home:
            return .orange
        case .study:
            return .blue
        case .electronics:
            return .purple
        case .clothing:
            return .pink
        case .other:
            return .gray
        }
    }
}
