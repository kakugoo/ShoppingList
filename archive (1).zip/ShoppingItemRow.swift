import SwiftUI

struct ShoppingItemRow: View {
    let item: ShoppingItem
    let onToggle: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Button(action: onToggle) {
                Image(
                    systemName: item.isPurchased
                        ? "checkmark.circle.fill"
                        : "circle"
                )
                .font(.title2)
                .foregroundStyle(
                    item.isPurchased ? .green : .secondary
                )
            }
            .buttonStyle(.plain)

            Image(systemName: item.category.icon)
                .font(.title2)
                .foregroundStyle(item.category.color)
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 4) {
                Text(item.name)
                    .font(.headline)
                    .strikethrough(item.isPurchased)

                Text(
                    "\(item.category.rawValue) · \(item.quantity) шт."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    ShoppingItemRow(item: ShoppingItem.samples[0]) {}
        .padding()
}
