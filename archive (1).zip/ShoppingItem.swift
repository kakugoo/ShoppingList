import Foundation

struct ShoppingItem: Identifiable, Hashable, Codable {
    let id: UUID
    var name: String
    var category: ShoppingCategory
    var quantity: Int
    var isPurchased: Bool

    init(
        id: UUID = UUID(),
        name: String,
        category: ShoppingCategory,
        quantity: Int = 1,
        isPurchased: Bool = false
    ) {
        self.id = id
        self.name = name
        self.category = category
        self.quantity = quantity
        self.isPurchased = isPurchased
    }
}

extension ShoppingItem {
    static let samples: [ShoppingItem] = [
        ShoppingItem(
            name: "Молоко",
            category: .food,
            quantity: 2
        ),
        ShoppingItem(
            name: "Блокнот",
            category: .study
        ),
        ShoppingItem(
            name: "Батарейки",
            category: .home,
            isPurchased: true
        )
    ]
}
