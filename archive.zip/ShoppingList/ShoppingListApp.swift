//
//  ShoppingListApp.swift
//  ShoppingList
//
//  Created by Андрей on 04.10.2026.
//

import SwiftUI

@main
struct ShoppingListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
