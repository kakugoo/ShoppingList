import SwiftUI

enum PurchaseFilter: String, CaseIterable, Identifiable {
    case all = "Все"
    case needed = "Нужно купить"
    case purchased = "Куплено"

    var id: Self { self }
}

struct ContentView: View {
    @State private var items = ShoppingItem.samples
    @State private var searchText = ""
    @State private var showingAddItem = false
    @State private var selectedFilter: PurchaseFilter = .all

    private var visibleItems: [ShoppingItem] {
        items.filter { item in

            let matchesSearch =
                searchText.isEmpty ||
                item.name.localizedCaseInsensitiveContains(searchText) ||
                item.category.localizedCaseInsensitiveContains(searchText)

            let matchesFilter: Bool

            switch selectedFilter {
            case .all:
                matchesFilter = true

            case .needed:
                matchesFilter = !item.isPurchased

            case .purchased:
                matchesFilter = item.isPurchased
            }

            return matchesSearch && matchesFilter
        }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("Фильтр", selection: $selectedFilter) {
                        ForEach(PurchaseFilter.allCases) { filter in
                            Text(filter.rawValue)
                                .tag(filter)
                        }
                    }
                    .pickerStyle(.segmented)
                }

                if visibleItems.isEmpty {
                    ContentUnavailableView.search(text: searchText)
                } else {
                    ForEach(visibleItems) { item in
                        NavigationLink(value: item.id) {
                            ShoppingItemRow(item: item) {
                                toggle(item)
                            }
                        }
                    }
                    .onDelete(perform: delete)
                }
            }
            .navigationTitle("Покупки")
            .searchable(text: $searchText, prompt: "Название или категория")
            .toolbar {
                Button("Добавить", systemImage: "plus") {
                    showingAddItem = true
                }
            }
            .sheet(isPresented: $showingAddItem) {
                AddShoppingItemView { newItem in
                    items.append(newItem)
                }
            }
            .navigationDestination(for: UUID.self) { id in
                if let index = items.firstIndex(where: { $0.id == id }) {
                    ShoppingItemDetailView(item: $items[index])
                }
            }
        }
    }

    private func toggle(_ item: ShoppingItem) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else {
            return
        }
        items[index].isPurchased.toggle()
    }

    private func delete(at offsets: IndexSet) {
        let ids = offsets.map { visibleItems[$0].id }
        items.removeAll { ids.contains($0.id) }
    }
}
